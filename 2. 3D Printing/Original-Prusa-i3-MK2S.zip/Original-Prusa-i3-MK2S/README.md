# Original Prusa i3 MK2S


Original Prusa i3 MK2S is a 3D printer project maintained by PRUSA RESEARCH.
Originates in RepRap project.

This repository contains SCAD files and STLs of the printed parts.

**Links**

 * Prusa Research website : http://prusa3d.com
 * Product page : http://shop.prusa3d.com/en/3d-printers/59-original-prusa-i3-mk2-kit.html
 * Build manual : http://manual.prusa3d.com/c/Original_Prusa_i3_MK2S_kit_assembly
 * Firmware : https://github.com/prusa3d/Prusa-Firmware

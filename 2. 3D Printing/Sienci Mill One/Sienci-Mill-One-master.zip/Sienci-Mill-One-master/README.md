# Sienci-Mill-One
The Sienci Mill One is an open source machine made by Sienci Labs that turns your ideas into reality by carving 3D objects from materials like wood, metal, plastic, foam, and PCB boards. 

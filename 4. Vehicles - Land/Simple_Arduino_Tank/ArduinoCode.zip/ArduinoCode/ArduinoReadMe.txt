2MotorSerialStepper.ino 

This code Requires 2 Libraries available through gethub
AccelStepper Library 
https://github.com/adafruit/AccelStepper/archive/master.zip

Adafruit Motor Shield (NOTE I Am using the older motor shield not the V2 one Modifications may/will be needed for using the newer shield ALSO a different Library See Adafruit
https://github.com/adafruit/Adafruit-Motor-Shield-library/zipball/master

This Code uses commands sent by Serial interface to control the 2 Stepper motors 

axxx, bxxx forward and backwards left side xxx speed
cxxx, dxxx forward and backwards right side xxx speed
exxx, fxxx forward and backwards both sides xxx speed
gxxx, hxxx Turn Left and Right sides xxx speed

For instance make sure newline is on in your serial interface and time e50 this should send the robot forward at half speed f50 will reverse the robot direction etc. 


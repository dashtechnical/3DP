# Modifications

In this folder you'll find the stl files of modifications that some users did. In particular these modifications allow to make Thor easier to print (splitted parts or smaller modifications). 

* [Danny-VdH](https://github.com/Danny-VdH) - Art2BodyASmall, Art2BodyBSmall, Art2BodyBCoverSmall & Art4Body modifications
* [Ctrl-Alt-Dude](http://www.thingiverse.com/ctrl-alt-dude/about) - BaseBot190mm modification

Thank you guys ;)
